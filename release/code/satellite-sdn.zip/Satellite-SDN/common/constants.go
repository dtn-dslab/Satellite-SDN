package common

const (
	RouteKeyPrefix  = "/github.com/dtn-dslab/Satellite-SDN/route"
	VersionPrefix   = "/version"
	RedisHostName   = "10.0.0.11"
	RedisServerPort = ":6379"
	PWD             = "sail123456"
	DB_SELECTED     = 0
)
