package main

import (
	"ws/dtn-satellite-sdn/cmd/app"
)

func main() {
	cmd.Execute()
}
