from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
import threading
import subprocess

import urllib
class Handler(BaseHTTPRequestHandler):

    def do_GET(self):
        name="World"    
        if '?' in self.path:#如果带有参数     
            self.queryString=urllib.parse.unquote(self.path.split('?',1)[1])     
            #name=str(bytes(params['name'][0],'GBK'),'utf-8')     
            params=urllib.parse.parse_qs(self.queryString)     
            print(params)     
            name=params["name"][0]
        print(name)
        self.send_response(200)
        self.send_header('Content-Type',
                         'text/plain; charset=utf-8')
        self.end_headers()          
        if self.path.find('/up')!=-1:
            cmd="kubectl exec -i -n wangshao "+name+" -- /bin/sh -c \"nohup /flow/load 70 &\""
            a=subprocess.call([cmd],shell=True) # shell参数为false，则，命令以及参数以列表的形式给出
            print(a)
            cmd="kubectl exec -i -n wangshao "+name+"-- /bin/sh -c \"iptables -t nat -A PREROUTING  -s 10.233.0.0/16 -j MARK --set-mark 0x4000\""
            a=subprocess.call([cmd],shell=False)    
        elif self.path.find('/down')!=-1:
            cmd="kubectl exec -i -n wangshao "+name+" -- /bin/sh -c \"killall -9 /flow/load\""
            a=subprocess.check_output([cmd],shell=True) # shell参数为false，则，命令以及参数以列表的形式给出    
            cmd="kubectl exec -i -n wangshao "+name+"-- /bin/sh -c \"iptables -t nat -D PREROUTING -s 10.233.0.0/16 -j MARK --set-mark 0x4000\""
            a=subprocess.call([cmd],shell=False)  
            print(a)             
 


if __name__ == '__main__':
    from http.server import HTTPServer
    server = HTTPServer(('10.0.0.11', 2113), Handler)
    print('Starting server, use <Ctrl-C> to stop')
    server.serve_forever()