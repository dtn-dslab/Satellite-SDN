package main

import (
	"time"
)

func main() {
	var n = 2 * time.Millisecond
	a := 10
	b := 5
	for {
		a = a + b + b
		b = a - b
		a %= 10
		b %= 10
		time.Sleep(n)
	}
}

//CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o load load.go
