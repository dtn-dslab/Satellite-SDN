package main

import (
	"fmt"
	"net/http"
	"os/exec"
	"time"
)

type Flow struct {
}
type Down struct {
}

func (f Flow) ServeHTTP(w http.ResponseWriter, req *http.Request) {
	cmd := exec.Command("bash", "-c", "/home/yu/Satellite-SDN/bin/sdnctl set -r server")
	stdout, err := cmd.CombinedOutput()
	if err != nil {
		fmt.Printf("error:%s", err.Error())
	} else {
		fmt.Print(string(stdout))
	}
	time.Sleep(5 * time.Second)
	cmd = exec.Command("bash", "-c", "/home/yu/Satellite-SDN/bin/sdnctl set -r client -b 20M")
	stdout, err = cmd.CombinedOutput()
	if err != nil {
		fmt.Printf("error:%s", err.Error())
	} else {
		fmt.Print(string(stdout))
	}
}

func (d Down) ServeHTTP(w http.ResponseWriter, req *http.Request) {
	print("10")
}
func main() {
	flow := Flow{}
	down := Down{}
	http.Handle("/flow", flow)
	http.Handle("/down", down)
	http.ListenAndServe(":10001", nil)
}
