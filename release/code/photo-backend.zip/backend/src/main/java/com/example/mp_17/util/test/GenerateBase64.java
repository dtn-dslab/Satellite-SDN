package com.example.mp_17.util.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Base64;

public class GenerateBase64 {
    public static String main() {
        // 指定JPEG文件路径
        // server
        // String filePath = "/home/admin/server/user1/1.jpg";
        // local
        String filePath = "C:/Users/xpk/Desktop/1.jpg";


        try {
            // 读取JPEG文件内容
            byte[] fileContent = readFileToByteArray(filePath);

            // 将文件内容编码为Base64字符串
            String base64String = encodeFileToBase64(fileContent);

            // 打印Base64字符串
            System.out.println("Base64 String: " + base64String);

            return base64String;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static byte[] readFileToByteArray(String filePath) throws IOException {
        File file = new File(filePath);
        byte[] fileContent = new byte[(int) file.length()];

        try (FileInputStream fis = new FileInputStream(file)) {
            fis.read(fileContent);
        }

        return fileContent;
    }

    private static String encodeFileToBase64(byte[] fileContent) {
        return Base64.getEncoder().encodeToString(fileContent);
    }
}
