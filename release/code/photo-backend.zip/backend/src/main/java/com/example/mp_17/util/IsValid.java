package com.example.mp_17.util;

public class IsValid {
    public static void main(String[] args){
        System.out.println(isValid("121.437963", "31.024303", "1"));
    }

    public static boolean isValid(String lng, String lat,String area){
        // 转化为double
        double lng_d = Double.parseDouble(lng);
        double lat_d = Double.parseDouble(lat);

        double[] areaCenter = new double[2];

        switch (area){
            case "0":
                areaCenter[0] = 0;
                areaCenter[1] = 0;
                break;
            case "1":
                areaCenter[0] = 121.437969;
                areaCenter[1] = 31.024298;
                break;
            default:
                return false;
        }

        // 生成中心点
        double centerLng = areaCenter[0];
        double centerLat = areaCenter[1];

        // 生成有效半径
        double RangeLng = 0.0002;  // 对应二十米
        double RangeLat = 0.0002;

        // 判断是否在有效范围
        if(lng_d > centerLng - RangeLng && lng_d < centerLng + RangeLng && lat_d > centerLat - RangeLat && lat_d < centerLat + RangeLat){
            return true;
        }

        return false;
    }
}
