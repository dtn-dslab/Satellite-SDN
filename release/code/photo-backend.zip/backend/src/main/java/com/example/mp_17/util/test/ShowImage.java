package com.example.mp_17.util.test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ShowImage {

    public static void main(String[] args) {
        // 替换下面的base64字符串为你的实际base64编码的图像数据
        String base64Image = Base64FromNet.getBase64();

        // 解码Base64字符串为字节数组
        byte[] imageBytes = Base64.getDecoder().decode(base64Image);

        // 创建字节数组输入流
        try (ByteArrayInputStream bis = new ByteArrayInputStream(imageBytes)) {
            // 读取图像
            ImageIcon imageIcon = new ImageIcon(ImageIO.read(bis));

            // 显示图像
            JFrame frame = new JFrame();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(new JLabel(imageIcon));
            frame.pack();
            frame.setVisible(true);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

