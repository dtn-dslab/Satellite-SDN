package com.example.mp_17.util;

public class GenerateValidArea {
    public static void main(String[] args){
    }

    // 生成有效区域
    public static double[][] generateValidArea(double centerLng,double centerLat){
        double RangeLng = 0.0002;  // 对应二十米
        double RangeLat = 0.0002;

        // 计算经度的范围
        double minLng = centerLng - RangeLng;
        double maxLng = centerLng + RangeLng;

        // 计算纬度的范围
        double minLat = centerLat - RangeLat;
        double maxLat = centerLat + RangeLat;

        // 返回经纬度的范围
        return new double[][]{{minLng, maxLng}, {minLat, maxLat}};
    }
}
