package com.example.mp_17.util.test;

import org.bytedeco.javacv.*;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;

public class Base64FromNet {

    public static void main(String[] args) {
        Base64FromNet test = new Base64FromNet();
        System.out.println(test.getBase64());
    }
    public static String getBase64(){
        Base64FromNet test = new Base64FromNet();
        return test.contextLoads();
    }

    String contextLoads() {
        // 202.120.40.122:61154
        String file = "rtsp://admin:@202.120.40.122:61154";
        FFmpegFrameGrabber grabber = new FFmpegFrameGrabber(file);
        grabber.setOption("rtsp_transport", "tcp");


        // System.out.println("grabber start");
        try {
            grabber.start();

            while (true) {
                Frame frame = grabber.grabImage();
                if (frame != null) {
                    //displayFrame(frame);
                    return encodeFrameToBase64(frame);
                } else {
                    System.out.println("图像未捕获");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                grabber.stop();
                grabber.release();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    private static String encodeFrameToBase64(Frame frame) {
        // 将 Frame 转换为字节数组
        byte[] frameBytes = convertFrameToBytes(frame);

        // 使用 Base64 编码
        return Base64.getEncoder().encodeToString(frameBytes);
    }

    private static byte[] convertFrameToBytes(Frame frame) {
        try {
            BufferedImage bufferedImage = Java2DFrameUtils.toBufferedImage(frame);

            // 将图像压缩到指定尺寸
            int targetWidth = 560;
            int targetHeight = 420;
            BufferedImage resizedImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
            resizedImage.createGraphics().drawImage(bufferedImage.getScaledInstance(targetWidth, targetHeight, java.awt.Image.SCALE_SMOOTH), 0, 0, null);

            // 创建字节数组输出流
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            // 将压缩后的图像写入字节数组输出流
            ImageIO.write(resizedImage, "jpg", byteArrayOutputStream);

            return byteArrayOutputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return new byte[0];
        }
    }

    private void displayFrame(Frame frame) {
        CanvasFrame canvasFrame = new CanvasFrame("摄像机");
        canvasFrame.setDefaultCloseOperation(CanvasFrame.EXIT_ON_CLOSE);
        canvasFrame.setAlwaysOnTop(true);

        Java2DFrameConverter converter = new Java2DFrameConverter();
        BufferedImage bufferedImage = converter.getBufferedImage(frame);
        canvasFrame.showImage(bufferedImage);
    }
}
