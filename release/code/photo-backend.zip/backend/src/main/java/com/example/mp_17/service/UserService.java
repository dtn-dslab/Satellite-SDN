package com.example.mp_17.service;

import com.example.mp_17.entity.User;
import com.example.mp_17.entity.Web;
import com.example.mp_17.entity.Process;
import com.example.mp_17.mapper.UserMapper;
import com.example.mp_17.util.GetTime;
import com.example.mp_17.util.IsValid;
import com.example.mp_17.util.test.Base64FromNet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;


@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    // web

    // web端提交任务
    public Boolean submitTask(String area, String monitoredPhone, String photoPhone, String camera){
        Web web = new Web();
        web.setArea(area);
        web.setMonitoredPhone(monitoredPhone);
        web.setPhotoPhone(photoPhone);
        web.setCamera(camera);
        return userMapper.submitTask(web);
    }

    // web端监控任务流程
    public Process monitorTask(){
        return userMapper.monitorTask();
    }

    // web端获取数据后删除
    public Boolean deleteTaskProcess(){
        return userMapper.deleteTaskProcess();
    }

    // web添加task process状态
    public Boolean addTaskProcess(){
        Process process = new Process();
        process.setTime(GetTime.getTime());
        process.setCamera(null);
        process.setPhone(null);
        process.setStage("1");
        return userMapper.addTaskProcess(process);
    }

    // web更新task process状态
    public Boolean updateTaskProcess(String camera,String phone, String stage){
        Process process = new Process();
        process.setCamera(camera);
        process.setPhone(phone);
        process.setStage(stage);
        return userMapper.updateTaskProcess(process);
    }

    // web更新task process里的camera变量
    public Boolean updateTaskProcessCamera(String camera){
        return userMapper.updateTaskProcessCamera(camera);
    }

    // web更新task process里的phone变量
    public Boolean updateTaskProcessPhone(String phone){
        return userMapper.updateTaskProcessPhone(phone);
    }

    // web更新task process里的stage变量
    public Boolean updateTaskProcessStage(String stage){
        return userMapper.updateTaskProcessStage(stage);
    }

    // web任务结束后删除Task
    public Boolean deleteTask(){
        return userMapper.deleteTask();
    }

    // web端获取实时位置
    public User webGetPosition(){
        return userMapper.webGetPosition();
    }

    // web端获取指定username的位置
    public User getSelectUser(String username){
        return userMapper.getSelectUser(username);
    }



    //app

    // 手机端持续监听，是否有任务请求
    public Web isTaskExist(){
        return userMapper.isTaskExist();
    }

    // 检测是否在有效区域
    public Boolean isPositionValid(String username,String area){
        User user = userMapper.getSelectUser(username);
        if (user == null){
            return false;
        }
        String lng = user.getLongitude();
        String lat = user.getLatitude();
        System.out.println(lng + " " + lat + " " + area);
        if (!IsValid.isValid(lng, lat, area)){
            return false;
        }
        return true;
    }

    // 手机端上传位置信息
    public Boolean UploadPositionInvalid(String username, String lng, String lat){
        if (userMapper.getSelectUser(username) == null){
            User user = new User();
            user.setTime(GetTime.getTime());
            user.setPhoto(null);
            user.setLongitude(lng);
            user.setLatitude(lat);
            user.setUsername(username);
            return userMapper.uploadPosition(user);
        }else{
            return updateSelectUser(username, lng, lat);
        }

    }

    // 手机端上传位置信息，在有效区域内，photo标记为1
    public Boolean UploadPositionValid(String username, String lng, String lat){
        User user = new User();
        user.setTime(GetTime.getTime());
        user.setPhoto("1");
        user.setLongitude(lng);
        user.setLatitude(lat);
        user.setUsername(username);
        userMapper.uploadPosition(user);

        String camera = Base64FromNet.getBase64();
        if(camera == null){
            userMapper.updateTaskProcessCamera("摄像机故障");
        }else{
            userMapper.updateTaskProcessCamera(camera);
        }

        return userMapper.updateTaskProcessStage("3");
    }

    // 更新指定用户的经纬度
    public Boolean updateSelectUser(String username, String lng, String lat){
        User user = new User();
        user.setLongitude(lng);
        user.setLatitude(lat);
        user.setUsername(username);
        return userMapper.updateSelectUser(user);
    }

    public Boolean UploadPosition(String username, String lng, String lat){
        User user = new User();
        user.setTime(GetTime.getTime());
        String Base64 = Base64FromNet.getBase64();
        System.out.println(Base64);
        user.setPhoto(Base64);
        user.setLongitude(lng);
        user.setLatitude(lat);
        user.setUsername(username);
        return userMapper.uploadPosition(user);
    }

    public List<User> getAllUers() {
        return userMapper.getAllUsers();
    }


}
