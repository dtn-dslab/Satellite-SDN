package com.example.mp_17.entity;

public class Process {

    private String time;
    private String camera;
    private String phone;
    private String stage;

    public Process() {
    }

    public String getTime() { return time; }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCamera() {
        return camera;
    }

    public void setCamera(String camera) {
        this.camera = camera;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }



}
