package com.example.mp_17.util;

import java.util.Random;

public class GenerateRandomPostion {
    public static void main(String[] args){

        double[] position = generateRandomPosition();
        System.out.println(position[0] + " " + position[1]);
    }

    public static double[] generateRandomPosition(){
        // 有效区域[-0.0002,0.0002]

        Random random = new Random();
        double min = -0.0004;
        double max = 0.0004;
        return new double[]{
                min + (max - min) * random.nextDouble(),
                min + (max - min) * random.nextDouble()
        };
    }


}
