package com.example.mp_17.entity;

public class Web {
    private String area;
    private String monitoredPhone;
    private String photoPhone;
    private String camera;

    public Web() {
    }

    public String getArea() {
        return area;
    }
    public void setArea(String area) {
        this.area = area;
    }
    public String getMonitoredPhone() {
        return monitoredPhone;
    }
    public void setMonitoredPhone(String monitoredPhone) {
        this.monitoredPhone = monitoredPhone;
    }
    public String getPhotoPhone() {
        return photoPhone;
    }
    public void setPhotoPhone(String photoPhone) {
        this.photoPhone = photoPhone;
    }
    public String getCamera() {
        return camera;
    }
    public void setCamera(String camera) {
        this.camera = camera;
    }

}
