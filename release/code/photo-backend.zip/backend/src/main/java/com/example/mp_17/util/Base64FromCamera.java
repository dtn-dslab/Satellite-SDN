package com.example.mp_17.util;

import org.bytedeco.javacv.*;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.OpenCVFrameGrabber;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;


public class Base64FromCamera {

    public static void main(String[] args){
        System.out.println(base64FromCamera());
        // base64FromCamera();
    }
    public static String base64FromCamera(){
        OpenCVFrameGrabber grabber = new OpenCVFrameGrabber(0);
        try {
            grabber.start();   //开始获取摄像头数据
        } catch (FrameGrabber.Exception e) {
            throw new RuntimeException(e);
        }

        // CanvasFrame canvas = new CanvasFrame("摄像头窗口");//新建一个窗口
        // canvas.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        // canvas.setAlwaysOnTop(true);
        //while (true) {
        Frame frame = null;
        System.out.println("frame: ");
        try {
            frame = grabber.grab();
        } catch (FrameGrabber.Exception e) {
            throw new RuntimeException(e);
        }

        // canvas.showImage(frame);    //获取摄像头图像并放到窗口上显示， 这里的Frame frame=grabber.grab(); frame是一帧视频图像
            //Thread.sleep(50);    //50毫秒刷新一次图像
        //}
        String base64Image = encodeFrameToBase64(frame);
        System.out.println(base64Image);

        try {
            grabber.stop();
        } catch (FrameGrabber.Exception e) {
            throw new RuntimeException(e);
        }

        return base64Image;
    }

    private static String encodeFrameToBase64(Frame frame) {
        // 将 Frame 转换为字节数组
        byte[] frameBytes = convertFrameToBytes(frame);

        // 使用 Base64 编码
        return Base64.getEncoder().encodeToString(frameBytes);
    }

    private static byte[] convertFrameToBytes(Frame frame) {
        try {
            // 将 Frame 转换为 BufferedImage
            BufferedImage bufferedImage = Java2DFrameUtils.toBufferedImage(frame);

            // 创建一个字节数组输出流
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

            // 将 BufferedImage 写入字节数组输出流
            javax.imageio.ImageIO.write(bufferedImage, "jpg", byteArrayOutputStream);

            // 获取字节数组
            return byteArrayOutputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return new byte[0];
        }
    }
}

