package com.example.mp_17.controller;


import com.example.mp_17.entity.Process;
import com.example.mp_17.entity.User;
import com.example.mp_17.entity.Web;
import com.example.mp_17.service.UserService;
import com.example.mp_17.util.GenerateRandomPostion;
import com.example.mp_17.util.GetTime;
import com.example.mp_17.util.IsValid;
import com.example.mp_17.util.test.Base64FromNet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Value;

import java.text.DecimalFormat;
import java.util.List;


@RestController
@CrossOrigin(origins = "*")
public class UserController {

    @Autowired
    private UserService userService;

    // web端

    // web端提交任务
    @RequestMapping("/web/submitTask")
    public Boolean submitTask(String area, String monitoredPhone, String photoPhone, String camera){
        userService.addTaskProcess();
        return userService.submitTask(area, monitoredPhone, photoPhone, camera);
    }

    // web端监听任务流程
    @RequestMapping("/web/monitorTask")
    public Process monitorTask(){
        Process process = new Process();
        process = userService.monitorTask();
        if (process.getCamera() != null && process.getPhone() != null){
            process.setStage("4");
            userService.deleteTaskProcess();
            userService.deleteTask();
            return process;
        }else{
            process.setCamera(null);
            process.setPhone(null);
            return process;
        }

    }

    // web端获取实时位置
    @RequestMapping("/web/getPosition")
    public User webGetPosition(String username){
        return userService.webGetPosition();
    }

    // web端获取指定用户的位置
    @RequestMapping("/web/getSelectUser")
    public User getSelectUser(String username){
        return userService.getSelectUser(username);
    }


    // web端任务结束后删除task
    @RequestMapping("/web/deleteTask")
    public Boolean deleteTask(){
        return userService.deleteTask();
    }

    // web端测试stage更新，可删
    @RequestMapping("/web/updateTaskProcess")
    public Boolean updateTaskProcess(String camera,String phone, String stage){
        return userService.updateTaskProcess(camera, phone, stage);
    }


    // 手机端

    // 手机端持续监听，是否有任务请求
    @RequestMapping("/app/isTaskExist")
    public String isTaskExist(String phoneId){
        Web web = new Web();
        web = userService.isTaskExist();
        if (web == null){
            return "0";
        }
        String monitoredPhone = web.getMonitoredPhone();
        String photoPhone = web.getPhotoPhone();
        if (monitoredPhone.equals(phoneId)){
            return "1";
        }else if (photoPhone.equals(phoneId)){
            return "2";
        }else {
            return "0";
        }

    }

    // 手机端访问判断是否到有效位置
    @RequestMapping("/app/isPositionValid")
    public Boolean isPositionValid(){
        Web web = userService.isTaskExist();
        String username = web.getMonitoredPhone();
        String area = web.getArea();
        if(userService.isPositionValid(username, area)){
            // 到达有效区域内，阶段一完成
            userService.updateTaskProcessStage("2");
            return true;
        }
        return false;
    }

    // 手机端上传位置信息
    @RequestMapping("/app/uploadPosition")
    public Boolean uploadPosition(String username,String lng, String lat){
        userService.UploadPositionInvalid(username,lng, lat);
        return true;
    }

    // 手机端上传照片
    @RequestMapping("/app/uploadPhonePhoto")
    public Boolean uploadPhonePhoto(String phone){
        userService.updateTaskProcessPhone(phone);
        String camera = Base64FromNet.getBase64();
        userService.updateTaskProcessCamera(camera);
        return userService.updateTaskProcessStage("3");
    }

    // 手机端上传位置信息,虚拟位置
    @RequestMapping("/app/simulate/uploadPosition")
    public boolean testUploadPhoto(String username, String lng, String lat){
        double[] sim_position = GenerateRandomPostion.generateRandomPosition();
        // 使用DecimalFormat来定义格式
        DecimalFormat decimalFormat = new DecimalFormat("0.00000000");
        // 格式化double值
        String sim_lng = decimalFormat.format(sim_position[0]);
        String sim_lat = decimalFormat.format(sim_position[1]);
        return userService.UploadPositionInvalid(username,sim_lng, sim_lat);
    }


    @RequestMapping("/refresh")
    public List<User> testRefresh(){
        return userService.getAllUers();
    }


    // 测试连接
    @RequestMapping("/test")
    public String test(){
        return "test";
    }
}
