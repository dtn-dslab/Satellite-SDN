package com.example.mp_17.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GetTime {
    public static void main(String[] args){
        // String a = getTime();
    }

    public static String getTime(){
        // 获取当前时间
        Date now = new Date();

        // 定义时间格式
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

        // 格式化时间为字符串
        String timestamp = dateFormat.format(now);

        return timestamp;
    }
}
