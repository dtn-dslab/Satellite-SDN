package com.example.mp_17.mapper;


import com.example.mp_17.entity.User;
import com.example.mp_17.entity.Web;
import com.example.mp_17.entity.Process;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface UserMapper {

    // web
    // web端提交任务
    Boolean submitTask(Web web);

    // web端监控任务流程
    Process monitorTask();

    // web端获取数据后删除
    Boolean deleteTaskProcess();

    // web添加task process状态
    Boolean addTaskProcess(Process process);

    // web更新task process状态
    Boolean updateTaskProcess(Process process);

    // web更新task process里的camera变量
    Boolean updateTaskProcessCamera(String camera);

    // web更新task process里的phone变量
    Boolean updateTaskProcessPhone(String phone);

    // web更新task process里的stage变量
    Boolean updateTaskProcessStage(String stage);

    // web任务结束后删除Task
    Boolean deleteTask();

    // web端获取实时位置
    User webGetPosition();


    // app
    // 获取是否有task
    Web isTaskExist();

    // 上传位置信息到message
    Boolean uploadPosition(User user);

    // 获取指定用户的信息
    User getSelectUser(String username);

    // 更新指定用户的经纬度
    Boolean updateSelectUser(User user);

    List<User> getAllUsers();



}
