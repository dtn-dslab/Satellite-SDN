package com.example.mp_17;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mp17Application {

	public static void main(String[] args) {
		SpringApplication.run(Mp17Application.class, args);
	}

}
