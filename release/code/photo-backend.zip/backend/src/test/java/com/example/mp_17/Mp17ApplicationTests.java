package com.example.mp_17;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mp17ApplicationTests {

	@Test
	void contextLoads() {
	}

}
