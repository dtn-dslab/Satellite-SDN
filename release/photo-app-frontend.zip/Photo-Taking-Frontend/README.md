# Photo-Taking-Frontend
An app front-end for taking photos and positioning
