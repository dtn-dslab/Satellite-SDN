package com.example.takephoto;

import static android.content.ContentValues.TAG;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.takephoto.utils.HttpPostRequest;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private String userid;

    private TextView showUser;

    private String role="0";

    private String listenRes;

    private boolean login=false;

    private ImageView imageView;

    private ActivityResultLauncher<Void> photoLauncher;


    //////to get locality
    private LocationManager locationManager;
    private String locationProvider;

    private String locationStr;
    private File photoFile;

    private String latitude;

    private String longitude;

    private String photo;

    //private Handler handler = new Handler(Looper.getMainLooper());

    ////

    private static final String TAG = "MainActivity";
    private static final long INTERVAL = 5000; // 5秒

    private Handler handler;

    private Handler handlerGetRole;

    private Handler handlerListen;

    private OkHttpClient client;
    private OkHttpClient client2;

    private boolean isRunning=false;

    private HandlerThread thread1;
    private HandlerThread thread2;

    private Handler mainHandler;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Context context = this;

        showUser=findViewById(R.id.showUserID);

        // 获取自定义布局视图
        View dialogView = getLayoutInflater().inflate(R.layout.id_layout, null);

        // 创建对话框构建器
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // 设置对话框标题
        builder.setTitle("输入ID");

        // 设置对话框的自定义布局
        builder.setView(dialogView);

        // 设置对话框按钮
        builder.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // 获取输入框的内容
                EditText editText = dialogView.findViewById(R.id.inputID);
                userid = "phone"+editText.getText().toString();
                Toast.makeText(MainActivity.this, "用户" + userid + "登陆成功！", Toast.LENGTH_SHORT).show();
                showUser.setText("用户："+userid);
                login=true;
                AskForRole();
            }
        });

        // 创建并显示对话框
        AlertDialog dialog = builder.create();
        dialog.show();


        handlerGetRole = new Handler(Looper.getMainLooper());
        //handlerToast = new Handler(Looper.getMainLooper());
        mainHandler = new Handler(Looper.getMainLooper());

        handler = new Handler(Looper.getMainLooper());
        handlerListen = new Handler(Looper.getMainLooper());

        client = new OkHttpClient();
        client2 = new OkHttpClient();

        imageView = findViewById(R.id.imageview);
        imageView.setOnClickListener(this);

//        Button test= findViewById(R.id.test);
//        test.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                restartApp();
//            }
//        });


        photoLauncher = registerForActivityResult(
                new ActivityResultContracts.TakePicturePreview(),
                new ActivityResultCallback<Bitmap>() {

                    @Override
                    public void onActivityResult(Bitmap result) {
                        if(result!=null) {
                            imageView.setImageBitmap(result);

                            Bitmap resizedBitmap = Bitmap.createScaledBitmap(result, 300, 200, false);


                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            resizedBitmap.compress(Bitmap.CompressFormat.JPEG, 30, baos); // 50 是质量压缩比例
                            byte[] byteArray = baos.toByteArray();

                            photo=Base64.encodeToString(byteArray, Base64.DEFAULT);
                            photoFile = saveImageToGallery(context, result);
                            if(photoFile==null) {
                                Toast message = Toast.makeText(getApplicationContext(), "bitmap转file失败", Toast.LENGTH_SHORT);
                                message.setGravity(Gravity.CENTER,0,0);
                                message.show();
                            } else {
                                Toast message = Toast.makeText(getApplicationContext(), "照片拍摄成功", Toast.LENGTH_SHORT);
                                message.setGravity(Gravity.CENTER,0,0);
                                message.show();

                            }
                            postPhoto();

                        }
                    }
                });


        ///////about location
        //执行运行时权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    Activity#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for Activity#requestPermissions for more details.
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
                ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},1);
                return;
            }
        }

        //获得LocationManager引用
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        //获取手机中开启的位置提供器
        List<String> providers = locationManager.getProviders(true);
        //选择获取方式
        if (providers.contains(LocationManager.NETWORK_PROVIDER)) {
            locationProvider = LocationManager.NETWORK_PROVIDER;
        } else if (providers.contains(LocationManager.GPS_PROVIDER)) {
            locationProvider = LocationManager.GPS_PROVIDER;
        } else {
            Toast.makeText(this,"定位失败",Toast.LENGTH_SHORT).show();
        }
        //周期性的位置更新，每隔3000ms更新位置，第三个参数监听位置的变化距离，单位米
        locationManager.requestLocationUpdates(locationProvider, 3000, 1, locationListener);


    }

    public void AskForRole() {
        startRepeatingAsk();
    }

    private Runnable runnableGetRole = new Runnable() {
        @Override
        public void run() {
                if(login) {
                    //getRoleRequest();
                    String url="http://202.120.40.93:30014/app/isTaskExist?phoneId="+userid;
                    Request request = new Request.Builder()
                            .url(url)
                            .build();

                    client.newCall(request).enqueue(new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            Log.e(TAG, "请求失败: " + e.getMessage());
                        }

                        @Override
                        public void onResponse(Call call, Response response) throws IOException {
                            if (response.isSuccessful()) {
                                String responseData = response.body().string();
                                // 处理响应数据
                                System.out.println("runnableGetRole");
                                role=responseData;
                                System.out.println(role);
                                if(role.equals("0")) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(MainActivity.this, "0", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                                else if(role.equals("1")) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(MainActivity.this, "开始位置提交", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }
                                else if(role.equals("2")) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(MainActivity.this, "开始监听", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }

                                Log.d(TAG, "响应数据: " + responseData);
                            } else {
                                Log.e(TAG, "服务器错误: " + response.code());
                            }
                            response.close();
                        }
                    });
                    if(role.equals("0")) {
                        handlerGetRole.postDelayed(this, INTERVAL);
                    }
                    else {
                        handlerGetRole.removeCallbacks(this);
                        ActAsRole();

                    }
                }
        }
    };
    public void startRepeatingAsk() {
        handlerGetRole.postDelayed(runnableGetRole, INTERVAL);
    }

    public void ActAsRole() {
        System.out.println("ActAsRole");
        System.out.println(role);

        isRunning=true;
        startListeningAndPosting();
    }


    public void onClick(View view) {
        if(view.getId()==R.id.imageview) {
            photoLauncher.launch(null);
        }
        //upload location
//        if (view.getId()==R.id.start) {
//
//            if(!isRunning) {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(MainActivity.this, "开始位置提交", Toast.LENGTH_SHORT).show();
//                    }
//                });
//                startRepeatingRequest();
//
//                isRunning=true;
//            }
//
//
//
//        }
//        else if(view.getId()==R.id.stop) {
//            handler.removeCallbacks(runnablePostPosition);
//            runOnUiThread(new Runnable() {
//                @Override
//                public void run() {
//                    Toast.makeText(MainActivity.this, "结束位置提交", Toast.LENGTH_SHORT).show();
//                }
//            });
//            isRunning=false;
//        }
//        else if(view.getId()==R.id.upload) {
//
////            Bitmap bm = BitmapFactory.decodeFile("/res/mipmap/pic");
////            if(bm!=null) {
////                imageView.setImageBitmap(bm);//不会变形
////            }
//
//            Toast message = Toast.makeText(getApplicationContext(), locationStr, Toast.LENGTH_SHORT);    //屏幕下方的弹窗
//
//            message.setGravity(Gravity.CENTER,0,0);
//            message.show();
//
//            //传bitmap=>转换为字节数组
//
//
//
//        }


    }


    //每隔5秒发送位置
    private Runnable runnablePostPosition = new Runnable() {
        @Override
        public void run() {
            if (isRunning) {
                // 执行你的事件操作
                makePostRequest();

                makeListenRequest();

                if(listenRes!=null && listenRes.equals("true")) {
                    handlerListen.removeCallbacks(this);
                    handler.removeCallbacks(runnablePostPosition);
                    checkAndStopThread();
                }
                else {
                    handler.postDelayed(this, INTERVAL); // 每隔5秒再次执行事件
                }
                //
            }
        }
    };

    public void makeListenRequest() {
        String url = "http://202.120.40.93:30014/app/isPositionValid";


        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "请求失败: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {

                    String responseData = response.body().string();

                    // 处理响应数据
                    listenRes = responseData;
                    if(responseData.equals("true")) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "目标到达位置", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    else if(responseData.equals("false")) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this, "目标未到达位置", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    Log.d("runnableListen", "响应数据: " + responseData);
                } else {
                    Log.e("runnableListen", "服务器错误: " + response.code());
                }
                response.close();
            }
        });
    }

    public void makePostRequest() {
        //202.120.40.93:30014
        //http://47.116.121.24:2938/app/simulate/uploadPosition?username=phone1&lng=0.00001&lat=0.00001
        String url = "http://202.120.40.93:30014/app/uploadPosition?username="+userid+"&lng="+longitude+"&lat="+latitude;
        //String url = "http://202.120.40.93:30014/app/uploadPosition?username="+userid+"&lng=121.437969&lat=31.024298";

        Log.d("runnablePost", "上传数据: " + longitude + "," + latitude);


        Request request = new Request.Builder()
                .url(url)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e(TAG, "请求失败: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    // 处理响应数据
                    //locationRes = responseData;
                    Log.d("runnablePost", "响应数据: " + responseData);
                } else {
                    Log.e("runnablePost", "服务器错误: " + response.code());
                }
                response.close();
            }
        });
    }

    public void postPhoto() {
        //            http://47.116.121.24:2938/app/uploadPhonePhoto?phone=+photo
        String url = "http://202.120.40.93:30014/app/uploadPhonePhoto?phone="+photo;


        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.e("postPhoto", "请求失败: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    Context context = getApplicationContext();
                    // 处理响应数据
                    if(responseData.equals("true")) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(context, "照片上传完成", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(context, "照片未上传完成", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    Log.d("postPhoto", "响应数据: " + responseData);
                } else {
                    Log.e("postPhoto", "服务器错误: " + response.code());
                }
                response.close();
            }
        });

        //新建一个窗口
        showCompleteDialog();
    }

    private void startListeningAndPosting() {
        ///////
//        thread = new Thread(new Runnable() {
//            @Override
//            public void run() {
//                Looper.prepare();
//
//                handler.postDelayed(runnablePostPosition, INTERVAL);
//                //handlerListen.postDelayed(runnableListen, INTERVAL);
//                Looper.loop();
//            }
//        });
//        thread.start();
        /////

//        thread1 = new HandlerThread("handlerThread");
//        thread1.start();
//        handler = new Handler(thread1.getLooper());
//        handler.postDelayed(runnablePostPosition, INTERVAL);
//
//
//        thread2 = new HandlerThread("HandlerThread2");
//        thread2.start();
//        //handlerToast=new Handler(getLooper());
//        handlerToast = new Handler(thread2.getLooper());
//        handlerListen = new Handler(thread2.getLooper());
//
//
//        handlerListen.postDelayed(runnableListen, INTERVAL);
//
//        try {
//            thread1.join();
//            thread2.join();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }

        ////
        handler.postDelayed(runnablePostPosition, INTERVAL);
    }

    public void checkAndStopThread() {
//        thread1.quitSafely();
//        thread2.quitSafely();
        if(role.equals("2")) {
            photoLauncher.launch(null);
        }
        else {
            //新建一个窗口
            showCompleteDialog();
        }
    }

    private void showCompleteDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("任务已完成")
                .setMessage("点击确定重新启动整个程序")
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // 点击确定按钮时重新启动整个应用程序
                        restartApp();
                    }
                })
                .setCancelable(false) // 防止用户点击对话框外部取消
                .show();
    }

    private void restartApp() {
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }


    //bitmap转file
    protected File bitmapToFile(Context context, Bitmap result) {
        // 获取外部存储目录
        File mediaStorageDir = new File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "takePhoto");
// 如果目录不存在，则创建它
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                return null;
            }
        }
        // 创建一个文件名，以当前时间为基础
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        File mediaFile = new File(mediaStorageDir.getPath() + File.separator + "IMG_" + timeStamp + ".jpg");


        Uri fileUri = Uri.fromFile(mediaFile);
        try {
            // 将Bitmap保存到文件
            FileOutputStream fos = new FileOutputStream(mediaFile);
            result.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.flush();
            fos.close();


            // 最后通知媒体库更新文件
            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, fileUri);
            context.sendBroadcast(mediaScanIntent);

            return mediaFile;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }

    }


    public File saveImageToGallery(Context context, Bitmap bmp) {
        //检查有没有存储权限
        if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            Toast.makeText(this, "请至权限中心打开应用权限", Toast.LENGTH_SHORT).show();
            return null;
        } else {
            // 新建目录appDir，并把图片存到其下
            File appDir = new File(context.getExternalFilesDir(null).getPath()+ "BarcodeBitmap");
            if (!appDir.exists()) {
                appDir.mkdir();
            }
            String fileName = System.currentTimeMillis() + ".jpg";
            File file = new File(appDir, fileName);
            try {
                FileOutputStream fos = new FileOutputStream(file);
                bmp.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                fos.flush();
                fos.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            // 把file里面的图片插入到系统相册中
            try {
                MediaStore.Images.Media.insertImage(context.getContentResolver(),
                        file.getAbsolutePath(), fileName, null);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            Toast.makeText(this, fileName, Toast.LENGTH_LONG);

            // 通知相册更新
            context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.fromFile(file)));
            return file;
        }
    }





    //位置监听器

    LocationListener locationListener = new LocationListener() {


        //状态发生变化时是使用
        @Override
        public void onStatusChanged(String provider, int status, Bundle arg2) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
        //信息更新时使用
        @Override
        public void onLocationChanged(Location location) {
            //获取精度
            double la = location.getLatitude();
            //获取纬度
            double lo = location.getLongitude();

            String addString = null;

            List<Address> addList = null;

//            Geocoder经纬度解码者可用于将经纬度转为具体位置信息
            Geocoder ge = new Geocoder(MainActivity.this);
            try {
                //通过经纬度获取地址值，由于地址可能有几个，这块限制为一个
                addList = ge.getFromLocation(la, lo, 1);
            } catch (IOException e) {

                e.printStackTrace();
            }
            if (addList != null && addList.size() > 0) {
                for (int i = 0; i < addList.size(); i++) {
                    Address ad = addList.get(i);
                    addString = ad.getLocality();//拿到城市
                }
            }
            if(addString != null) {
                Toast.makeText(MainActivity.this,addString,Toast.LENGTH_SHORT).show();
            }
            locationStr = "维度：" + location.getLatitude()
                    +"\n"
                    + "经度：" + location.getLongitude();
            Log.i("andly", locationStr + "----" + addString);
            latitude=String.valueOf(location.getLatitude());
            longitude=String.valueOf(location.getLongitude());
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (locationManager != null) {
            //关闭时程序时，移除监听器
            locationManager.removeUpdates(locationListener);
        }
    }



}